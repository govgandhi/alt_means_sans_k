/*!

@authors Andrei Novikov (pyclustering@yandex.ru)
@date 2014-2020
@copyright BSD-3-Clause

*/


#pragma once


namespace pyclustering {

namespace nnet {


enum class initial_type {
    RANDOM_GAUSSIAN,
    EQUIPARTITION,
};


}

}