"""!

@brief Cloud Tool for Yandex Disk service.
@details The tool has been implemented to support CI infrastructure of pyclustering library.

@authors Andrei Novikov (pyclustering@yandex.ru)
@date 2014-2020
@copyright BSD-3-Clause

"""
